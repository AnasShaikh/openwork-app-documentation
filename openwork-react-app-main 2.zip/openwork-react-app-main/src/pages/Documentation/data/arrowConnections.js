// Arrow connections between contracts
export const arrowConnections = [];
